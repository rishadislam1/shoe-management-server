# Project Details
 ## Project Name: Shoe Inventory Management System
 ## live Url: https://l2b2-full-stack-a5-server-side-rishadislam1-two.vercel.app/
 ## Technology: nodejs, expressjs, cors, mongoDB

# How to setup the application.

First of all you can see this github. From this github you can either copy the link from code and in your terminal just put git clone "your link", it will automatically copy to your local machine and you can see the code or you can download from here directly. 
No matter what you choose. You can choose any of them. Now in your folder open your terminal and write the codes respectively,
```
  npm install node-modules
  nodemon index.js
```
Then your code will automatically run and after clicking the url you can see the project view.

Make Sure you have nodemon install in your device.

### If you don't have nodemon run this command

```
npm i nodemon
```
